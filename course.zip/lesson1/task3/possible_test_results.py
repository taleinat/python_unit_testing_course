import unittest


class TestPossibleResults(unittest.TestCase):
    def test_success(self):
        write a test which will succeed

    def test_failure(self):
        write a test which will fail

    def test_error(self):
        write a test which will cause an error
