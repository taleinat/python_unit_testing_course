import unittest

from hello_someone import hello_someone


class TestHelloWorld(unittest.TestCase):
    def test_hello_world(self):
        test that the function returns "Hello, World!" when called with the appropriate input argument
